const addBtn = document.querySelector("#add_new_note_button");
const main = document.querySelector("#main");
const colors = ["#FF6B6B", "#4ECDC4", "#1A535C", "#FFD166", "#06D6A0", "#118AB2", "#073B4C", "#EF476F", "#FFD166", "#06D6A0", "#8338EC", "#3A86FF"]; // Add more colors as needed

// Click event listener
addBtn.addEventListener("click", function () {
    addNote();
});


const addNote = (text = "", title = "", category = "") => {
    const note = document.createElement("div");
    note.classList.add("note");
    const color = colors[Math.floor(Math.random() * colors.length)];
    note.innerHTML = `
    <div class="icons">
        <i class="save fas fa-save" style="color:${color}"></i>
        <i class="trash fas fa-trash" style="color:${color}"></i>
    </div>
    <div class="title-div">
        <textarea class="title" placeholder="Write title ..." style="background-color:${color}">${title}</textarea>
    </div>
    <textarea class="content" placeholder="Note down your thoughts ..." style="background-color:${color}">${text}</textarea>
    `;

    function handleTrashClick() {
        note.remove();
        saveNotes();
    }

    function handleSaveClick() {
        saveNotes();
    }

    const delBtn = note.querySelector(".trash");
    const saveButton = note.querySelector(".save");

    delBtn.addEventListener("click", handleTrashClick);
    saveButton.addEventListener("click", handleSaveClick);

    main.appendChild(note);
    saveNotes();
};